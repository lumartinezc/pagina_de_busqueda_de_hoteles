<?php

class AutenticacionHelper{

    function __construct(){
    }

    function checkLoggedIn(){
        session_start();
        if(isset($_SESSION["usuario"])){
            // header("Location: ".BASE_URL."login");
            return $_SESSION["usuario"];
        }
    }

    function estaLogueado(){
        session_start();
        if(!isset($_SESSION["usuario"])){
            header("Location: ".BASE_URL."login");
            // return $_SESSION["usuario"];
        }
    }

    // function botonMenu(){
    //     session_start();
    //     if(!isset($_SESSION["usuario"])){
    //         $var = 'login';
    //         // return $var;
    //     }
    //     else {
    //         $var = 'Logout';
    //         // $nombre = $_SESSION["usuario"];
    //     }
    //     return $var;

    // }
}