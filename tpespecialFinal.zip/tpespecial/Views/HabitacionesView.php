<?php

require_once 'libs/smarty-3.1.39/libs/Smarty.class.php';

class HabitacionesView {

    private $smarty;

    function __construct() {
        $this->smarty = new Smarty();
    }

    function listarHabitaciones($habitaciones, $usuario, $hoteles) {
        if(isset($usuario)) {
            $this->smarty->assign('usuario', $usuario);
        }
        else {
            $this->smarty->assign('usuario', null);
        }

        if(isset($habitaciones[0]->Nombre_hotel)){
            $this->smarty->assign('titulo', $habitaciones[0]->Nombre_hotel);
        }    
        else if(empty($habitaciones)) {
            $this->smarty->assign('titulo', 'No hay habitaciones disponibles para este hotel');    
        }
        else{
            $this->smarty->assign('titulo','Habitaciones');   
        }
        $this->smarty->assign('habitaciones', $habitaciones);
        $this->smarty->assign('hoteles', $hoteles);
        $this->smarty->display('templates/habitaciones.tpl');
    }

    function mostrarHabitacionPorId($habitacion, $usuario) {
        if(isset($usuario)) {
            $this->smarty->assign('usuario', $usuario);
        }
        else {
            $this->smarty->assign('usuario', null);
        }
        $this->smarty->assign('habitacion', $habitacion);
        $this->smarty->assign('titulo', $habitacion->Nombre_habitacion);
        $this->smarty->assign('nombreHotel', $habitacion->Nombre_hotel);
        $this->smarty->display('templates/habitacionesDescripcion.tpl');
    }

    function mostrarEditForm($habitacion, $hoteles) {
        $this->smarty->assign('hoteles', $hoteles);
        $this->smarty->assign('id', $habitacion->ID_HABITACION);
        $this->smarty->assign('idHotel', $habitacion->ID_HOTEL);
        $this->smarty->assign('nombre', $habitacion->Nombre_habitacion);
        $this->smarty->assign('descripcion', $habitacion->Descripcion);
        $this->smarty->assign('cantCamas', $habitacion->Cantidad_camas);
        $this->smarty->assign('capacidad', $habitacion->Capacidad);
        $this->smarty->assign('precio', $habitacion->Precio);
        $this->smarty->assign('disponible', $habitacion->Disponible);
        $this->smarty->display('templates/editHabitaciones.tpl');
    }

    function showHabitacionesLocation() {
        header("Location: ".BASE_URL."habitaciones");
    }
}

// class HabitacionesView {

//     function __construct () {

//     }

//     function mostrarHabitaciones ($habitaciones) {
//         $html = '
//         <!DOCTYPE html>
//             <html lang="en">
//             <head>
//                 <meta charset="UTF-8">
//                 <meta http-equiv="X-UA-Compatible" content="IE=edge">
//                 <meta name="viewport" content="width=device-width, initial-scale=1.0">
//                 <base href="'.BASE_URL.'">
//                 <title>Document</title>
//             </head>
//             <body>
//                 <h1>'.$habitaciones[0]->Nombre_hotel.'</h1>
//                 <table>
//                     <thead>
//                         <tr>
//                             <th>Nombre</th>
//                             <th>Descripcion</th>
//                             <th>Cantidad de camas</th>
//                             <th>Capacidad</th>
//                             <th>Precio</th>
//                             <th>Disponible</th>
//                         </tr>
//                     </thead>
//                     <tbody>';
//         foreach($habitaciones as $habitacion) {
//             $html .= '
//             <tr>
//                 <td>'.$habitacion->Nombre.'</td>
//                 <td>'.$habitacion->Descripcion.'</td>
//                 <td>'.$habitacion->Cantidad_camas.'</td>
//                 <td>'.$habitacion->Capacidad.'</td>
//                 <td>'.$habitacion->Precio.'</td>';
//                 if($habitacion->Disponible == 1) {
//                     $html .= '<td>Disponible<td>';
//                 }
//                 else {
//                     $html .= '<td>No disponible<td>';
//                 }
//         ;
//         }    
//         $html .= '</tr>
//                 </tbody>
//                 </table>
//             </body>
//             </html>
//         ';
//         echo $html;

//     }

//     function listarHabitaciones ($habitaciones) {
//         $html = '
//         <!DOCTYPE html>
//             <html lang="en">
//             <head>
//                 <meta charset="UTF-8">
//                 <meta http-equiv="X-UA-Compatible" content="IE=edge">
//                 <meta name="viewport" content="width=device-width, initial-scale=1.0">
//                 <base href="'.BASE_URL.'">
//                 <title>Document</title>
//             </head>
//             <body>
//                 <h1>Habitaciones</h1>
//                 <ul>';
//         foreach($habitaciones as $habitacion) {
//             $html .= '<li><a href="habitacion/'.$habitacion->ID_HABITACION.'">'.$habitacion->Nombre.' del hotel </a> <a href="delete/'.$habitacion->ID_HABITACION.'"><button>Borrar</button></a> <a href="edit/'.$habitacion->ID_HABITACION.'"><button>Editar</button></a></li>';
//         }    
//         $html .= '
//                 </ul>
//             </body>
//             </html>
//         ';
//         echo $html;

//     }

//     function mostrarHabitacionPorId($habitacion) {
//         $html = '
//         <!DOCTYPE html>
//             <html lang="en">
//             <head>
//                 <meta charset="UTF-8">
//                 <meta http-equiv="X-UA-Compatible" content="IE=edge">
//                 <meta name="viewport" content="width=device-width, initial-scale=1.0">
//                 <base href="'.BASE_URL.'">
//                 <title>Document</title>
//             </head>
//             <body>
//                 <table>
//                     <thead>
//                         <tr>
//                         <th>Nombre</th>
//                         <th>Descripcion</th>
//                         <th>Cantidad de camas</th>
//                         <th>Capacidad</th>
//                         <th>Precio</th>
//                         <th>Disponible</th>
//                         <th>Nombre del Hotel</th>
//                         <th>Direccion</th>
//                         <th>Telefono</th>
//                         <th>Puntuacion</th>
//                         </tr>
//                     </thead>
//                     <tbody>';
//         $html .= '<tr>
//                     <td>'.$habitacion->Nombre.'</td>
//                     <td>'.$habitacion->Descripcion.'</td>
//                     <td>'.$habitacion->Cantidad_camas.'</td>
//                     <td>'.$habitacion->Capacidad.'</td>
//                     <td>'.$habitacion->Precio.'</td>';
//         if($habitacion->Disponible == 1) {
//             $html .= '<td>Disponible<td>';
//         } else 
//             $html .= '<td>No disponible<td>';
//         $html.='
//             <td>'.$habitacion->Nombre_hotel.'</td>
//             <td>'.$habitacion->Direccion.'</td>
//             <td>'.$habitacion->Telefono.'</td>
//             <td>'.$habitacion->Puntuacion.'</td>'
//             ;
//         $html .='</tr>
//                 </tbody>
//                 </table>
//             </body>
//             </html>
//         ';
//         echo $html;
//     }
// }
