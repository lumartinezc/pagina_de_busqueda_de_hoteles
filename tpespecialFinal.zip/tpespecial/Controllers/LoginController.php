<?php
    require_once './Models/UserModel.php';
    require_once './Views/LoginView.php';
    require_once './Views/HomeView.php';
    // require_once './Helpers/AutenticacionHelper.php';

    class LoginController {

        private $model;
        private $view;
        private $homeView;
        // private $authy;

        function __construct(){
            $this->model = new UserModel();
            $this->view = new LoginView();
            $this->homeView = new HomeView();
            // $this->authy = new AutenticacionHelper();
        }

        function mostrarLogin() {
            $this->view->mostrarLoginForm(null);
        }

        function mostrarRegistro() {
            // $this->authy->checkLoggedIn();
            //ACA TMB DEBERIA PONERSE UN AUTENTICADOR PARA VER SI HAY ALGUN USUARIO CON SESION INICIADA
            //PORQUE SE INICIO SESION, Y LUEGO VOY A REGISTRO O A LOGIN NUNCA VERIFICO SI HAY ALGUNA
            //SESION INICIADA. POR LO TANTO NO ME VA A MOSTRAR EL OMBRE COMO LO VIENE HACIENDO HASTA AHORA
            $this->view->mostrarRegistroForm();
        }

        function enviarRegistro() {
            if(!empty($_POST['nombre']) && !empty($_POST['apellido'] && !empty($_POST['email']) && !empty($_POST['usuario']) && !empty($_POST['contraseña']))){
                $this->model->sendRegistro($_POST['nombre'], $_POST['apellido'], $_POST['email'], $_POST['usuario'], $_POST['contraseña']);
                $this->view->mostrarLoginForm('Su registro se ha completado con exito, utilice los datos cargados previamente para iniciar sesion');
            }
        }

        function verificarLogin() {
            if (!empty($_POST['usuario']) && !empty($_POST['contraseña'])) {
                $usuario = $_POST['usuario'];
                $password = $_POST['contraseña'];
         
                // Obtengo el usuario de la base de datos
                $user = $this->model->obtenerUsuario($usuario);

         
                // Si el usuario existe y las contraseñas coinciden
                if ($user && password_verify($password, ($user->Contraseña))) {
    
                    session_start();
                    $_SESSION["usuario"] = $user->Usuario;
                    // $variable = 'Logout';
                    $this->homeView->showHome();
                    // header('Location: '.BASE_URL.'');

                } else {
                    $this->view->mostrarLoginForm("El nombre del usuario o la contraseña son incorrectos, intentelo nuevamente");
                }
            }
        }

        function logout(){
            session_start();
            session_destroy();
            $_SESSION['usuario'] = '';
            $this->view->mostrarLoginForm("Tu sesión ha sido cerrada.
            ¡Gracias por utilizar nuestro servicio!");
        }
    }