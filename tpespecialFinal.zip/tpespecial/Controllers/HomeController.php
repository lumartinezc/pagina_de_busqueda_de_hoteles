<?php

// require_once './Controllers/HeaderController.php';
require_once './Views/HomeView.php';
require_once './Helpers/AutenticacionHelper.php';

class HomeController {
    private $view;
    private $authy;
    // private $header;

    function __construct() {
        $this->view = new HomeView();
        $this->authy = new AutenticacionHelper();
        // $this->header = new HeaderController();
    }
    function showHome() {
        $this->authy->checkLoggedIn();
        // $this->header->eleginBoton();
        $this->view->showHome();
    }
}