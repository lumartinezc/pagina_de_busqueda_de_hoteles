<?php

require_once './Views/HeaderView.php';
require_once './Helpers/AutenticacionHelper.php';

class HeaderController {
    private $view;
    private $authy;

    function __construct() {
        $this->view = new HomeView();
        $this->authy = new AutenticacionHelper();
    }
    function elegirBoton() {
        $var = $this->authy->botonMenu();
        $this->view->elegirBtnMenu($var);
    }
}