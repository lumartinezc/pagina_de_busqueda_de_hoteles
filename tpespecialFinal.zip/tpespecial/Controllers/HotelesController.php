<?php

require_once './Models/HotelModel.php';
require_once './Models/HabitacionesModel.php';
require_once './Views/HotelView.php';
require_once './Views/HabitacionesView.php';
require_once './Helpers/AutenticacionHelper.php';
// require_once './Views/HeaderView.php';


class HotelesController {
    private $model;
    private $modelHabitaciones;
    private $view;
    // private $headerView;
    private $viewHabitaciones;
    private $authy;


    function __construct() {
        $this->model = new HotelModel();
        $this->modelHabitaciones = new HabitacionesModel();
        $this->view = new HotelView();
        $this->viewHabitaciones = new HabitacionesView();
        $this->authy = new AutenticacionHelper();
        // $this->headerView = new HeaderView();
    }
    //EL TEMA ESTA EN QUE SI NO ESTA LOGUEADO LA VARIABLE HECHA EN CLASE TE MANDA DIRECTO AL
    //LOGIN, POR LO TANTO UNA IDEA Q TENGO ES DE HACER LO QUE ESTA ABAJO.
    
    //HACER LO DE CHECKEDLOGGEDIN Y MANDAR UNA VARIABLE A mostrarHoteles($hoteles, $variable)
    //SI NO ESTA LOGUEADO MANDAR 'NO', SINO MANDAR 'SI'. TODO ESTO ADENTRO DE UN IF. SIGUE EN HOTELVIEW
    function showHoteles() {
        $usuario = $this->authy->checkLoggedIn();
        $hoteles = $this->model->traerHoteles();
        // $this->headerView->elegirBtnMenu($_SESSION["usuario"]);
        $this->view->mostrarHoteles($hoteles, $usuario);
    }

    function showHotel($id) {
        $usuario = $this->authy->checkLoggedIn();
        $hotel = $this->model->traerHotelPorId($id);
        $this->view->mostrarHotelPorId($hotel, $usuario);
    }

    function showHabitacionesPorHotel($id) {
        $usuario = $this->authy->checkLoggedIn();
        $habitaciones = $this->modelHabitaciones->traerHabitaciones($id);
        $hoteles = $this->model->traerHoteles();
        $this->viewHabitaciones->listarHabitaciones($habitaciones, $usuario, $hoteles);
    }

    function createHotel() {
        $this->authy->estaLogueado();
        $this->model->insertHotel($_GET['nombre'], $_GET['direccion'], $_GET['telefono'], $_GET['puntuacion'], $_GET['cant-habitaciones']);
        $this->view->showHotelesLocation();
    }

    function deleteHotel($id) {
        $this->authy->estaLogueado();
        $this->model->delete_Hotel($id);
        $this->view->showHotelesLocation();
    }

    function editarHotel($id) {
        $this->authy->estaLogueado();
        $hotel = $this->model->traerHotelPorId($id);
        $this->view->mostrarEditForm($hotel);
    }

    function enviarHotelEditado($id) {
        $this->authy->estaLogueado();
        $this->model->editarHotel($_GET['nombre'], $_GET['direccion'], $_GET['telefono'], $_GET['puntuacion'], $_GET['cantHabitaciones'], $id);
        $this->view->showHotelesLocation();
    }

    function buscarHotel() {
        if(isset($_POST['buscar'])) {
            $usuario = $this->authy->checkLoggedIn();
            $palabra = $_POST['buscar'];
            $hotel = $this->model->buscar($palabra);
            // var_dump($hotel);
            $this->view->mostrarHoteles($hotel, $usuario);
        }
    }
}

// EL FORMULARIO AGREGARHOTEL SALGA DE UN BOTON QUE ME LLEVE A HOTELESCONTROLLER, TRAIGA
//LOS HOTELES MAS EL ID Y LOS PONGA EN EL FORMULARIO