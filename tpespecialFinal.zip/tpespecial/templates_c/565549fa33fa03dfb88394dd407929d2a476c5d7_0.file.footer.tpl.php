<?php
/* Smarty version 3.1.39, created on 2021-10-14 19:11:40
  from '/opt/lampp/htdocs/tpespecial/templates/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_616864cc808400_14982122',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '565549fa33fa03dfb88394dd407929d2a476c5d7' => 
    array (
      0 => '/opt/lampp/htdocs/tpespecial/templates/footer.tpl',
      1 => 1634231499,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_616864cc808400_14982122 (Smarty_Internal_Template $_smarty_tpl) {
?><footer>
    <div class="contacto">
        <div class="titulofooter">
            <h5>Contactanos</h5>
        </div>
        <div class="datacontacto">
            <h6>alquilerestandil@hotmail.com</h6>
            <h6>Tel 1549685533</h6>
            <h6>Las heras 888 Tandil, Argentina</h6>
        </div>
       
    </div>
    <div class="menufooter">
        <h6>Quienes Somos</h6>
        <h6>Soporte Tecnico</h6>
        <h6>Terminos y condiciones</h6>
        <h6>Trabajá con nosotros</h6>
    </div>
</footer>
<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"><?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
