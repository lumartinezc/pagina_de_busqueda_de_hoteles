// document.addEventListener('DOMContentLoaded', cargarModal);
// let myModal = document.querySelector('.modal')
// function cargarModal() {
//     document.querySelectorAll('.btn-editar').forEach(btn => {
//         btn.addEventListener('click', ()=>{
//             myModal.classList.remove('mostrar');
//             id = this.dataset.id;

//         })
//     })
    
    
// }